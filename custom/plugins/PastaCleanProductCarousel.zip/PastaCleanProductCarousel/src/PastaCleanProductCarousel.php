<?php

namespace PastaClean\ProductCarousel;

use Shopware\Core\Framework\Plugin;

class PastaCleanProductCarousel extends Plugin
{
}
