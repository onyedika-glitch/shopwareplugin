# PastaCleanCarousel - Shopware 6 Plugin

Amazon-style product image carousel plugin for Shopware 6.

Installation:
1. Place the folder `PastaCleanCarousel` into `custom/plugins/`.
2. From project root run:
   - `bin/console plugin:refresh`
   - `bin/console plugin:install --activate PastaCleanCarousel`
   - `bin/console theme:compile`
   - `bin/console cache:clear`
